import { Report, ReportType, AnalysisResult } from '../types';

// Sample reports
export const sampleReports: Report[] = [
  {
    id: '1',
    title: 'Complete Blood Count',
    date: '2025-04-12',
    content: 'WBC: 7.2 k/uL, RBC: 4.8 m/uL, Hemoglobin: 14.2 g/dL, Hematocrit: 42.1%, Platelets: 290 k/uL...',
    type: ReportType.LAB,
    analyzed: true
  },
  {
    id: '2',
    title: 'Chest X-Ray Results',
    date: '2025-04-10',
    content: 'PA and lateral views of the chest demonstrate clear lung fields. No evidence of consolidation, effusion, or pneumothorax...',
    type: ReportType.RADIOLOGY,
    analyzed: true
  },
  {
    id: '3',
    title: 'Liver Function Tests',
    date: '2025-04-05',
    content: 'ALT: 28 U/L, AST: 24 U/L, ALP: 67 U/L, Total Bilirubin: 0.8 mg/dL, Direct Bilirubin: 0.2 mg/dL...',
    type: ReportType.LAB,
    analyzed: true
  },
  {
    id: '4',
    title: 'Hospital Discharge Summary',
    date: '2025-03-28',
    content: 'Patient was admitted on 03/25/2025 with chief complaint of chest pain. Cardiac workup negative for acute coronary syndrome...',
    type: ReportType.DISCHARGE,
    analyzed: false
  }
];

// Sample analysis results
export const sampleAnalysisResults: Record<string, AnalysisResult> = {
  '1': {
    summary: 'Your Complete Blood Count (CBC) results are mostly within normal ranges, with all key parameters showing healthy values. This test measures various components and features of your blood, including red blood cells, white blood cells, and platelets. Based on these results, there are no significant abnormalities that would indicate blood disorders, infections, or other health concerns that can be detected through CBC analysis.',
    keyFindings: [
      {
        text: 'White Blood Cell Count: 7.2 k/uL',
        explanation: 'Your white blood cell count is within the normal range (4.5-11.0 k/uL), suggesting a normal immune response without signs of infection or inflammation.',
        severity: 'normal'
      },
      {
        text: 'Hemoglobin: 14.2 g/dL',
        explanation: 'Your hemoglobin level is normal, indicating good oxygen-carrying capacity in your blood.',
        severity: 'normal'
      },
      {
        text: 'Platelet Count: 290 k/uL',
        explanation: 'Your platelet count is within normal limits, suggesting normal blood clotting function.',
        severity: 'normal'
      }
    ],
    abnormalValues: [
      {
        name: 'Lymphocytes',
        value: '39',
        unit: '%',
        referenceRange: '20-40%',
        interpretation: 'High normal, but still within acceptable range'
      }
    ],
    recommendations: [
      'Continue with routine health maintenance and follow up with your healthcare provider as scheduled.',
      'Maintain a balanced diet rich in iron, folate, and vitamin B12 to support healthy blood cell production.',
      'Consider a follow-up CBC in 12 months as part of your routine health screening.'
    ]
  },
  '2': {
    summary: 'Your chest X-ray shows normal findings with clear lung fields. The heart size appears normal and there are no signs of consolidation, effusion, or pneumothorax. The bony structures and soft tissues appear normal as well. This is a reassuring result indicating no evidence of acute cardiopulmonary disease.',
    keyFindings: [
      {
        text: 'Clear lung fields bilaterally',
        explanation: 'Your lungs appear clear without signs of infection, fluid, or masses.',
        severity: 'normal'
      },
      {
        text: 'Normal heart size and contour',
        explanation: 'Your heart appears normal in size, suggesting normal cardiac function.',
        severity: 'normal'
      },
      {
        text: 'No pleural effusion',
        explanation: 'There is no evidence of fluid accumulation in the space surrounding your lungs.',
        severity: 'normal'
      }
    ],
    abnormalValues: [],
    recommendations: [
      'No follow-up imaging is necessary at this time based on these normal findings.',
      'Continue to report any new or worsening respiratory symptoms to your healthcare provider.',
      'Follow general health guidelines for lung health, including avoiding smoking and minimizing exposure to air pollutants.'
    ]
  },
  '3': {
    summary: 'Your liver function tests show values within normal ranges, indicating normal liver function. These tests measure various enzymes, proteins, and substances that reflect the health of your liver. Based on these results, there is no evidence of liver damage, disease, or dysfunction.',
    keyFindings: [
      {
        text: 'ALT: 28 U/L',
        explanation: 'Alanine transaminase is within normal range (7-55 U/L), suggesting no significant liver cell damage.',
        severity: 'normal'
      },
      {
        text: 'AST: 24 U/L',
        explanation: 'Aspartate transaminase is within normal range (8-48 U/L), further supporting normal liver function.',
        severity: 'normal'
      },
      {
        text: 'Total Bilirubin: 0.8 mg/dL',
        explanation: 'Your bilirubin level is normal (0.1-1.2 mg/dL), indicating normal processing of old red blood cells.',
        severity: 'normal'
      }
    ],
    abnormalValues: [],
    recommendations: [
      'Continue healthy lifestyle habits to maintain liver health, including limiting alcohol consumption.',
      'Maintain a balanced diet and regular exercise regime.',
      'Consider routine liver function testing annually or as recommended by your healthcare provider.'
    ]
  }
};

// Medical terminology with explanations
export const medicalTerminology: Record<string, string> = {
  'WBC': 'White Blood Cells - Cells of the immune system that protect the body against infectious disease and foreign invaders.',
  'RBC': 'Red Blood Cells - Cells that carry oxygen from the lungs to the tissues and carbon dioxide from the tissues to the lungs.',
  'Hemoglobin': 'A protein in red blood cells that carries oxygen from the lungs to the tissues of the body.',
  'Hematocrit': 'The percentage of blood volume that is occupied by red blood cells.',
  'Platelets': 'Small blood cells that help your body form clots to stop bleeding.',
  'ALT': 'Alanine Transaminase - An enzyme found primarily in the liver; elevated levels may indicate liver damage.',
  'AST': 'Aspartate Transaminase - An enzyme found in the liver, heart, and muscles; elevated levels may indicate damage to these organs.',
  'ALP': 'Alkaline Phosphatase - An enzyme found in many tissues, with the highest concentrations in the liver, bile ducts, and bone.',
  'Bilirubin': 'A yellow compound produced during the breakdown of old red blood cells. High levels cause jaundice.',
  'Effusion': 'Abnormal accumulation of fluid within a body cavity, such as around the lungs (pleural effusion).',
  'Pneumothorax': 'A collapsed lung that occurs when air leaks into the space between the lung and chest wall.',
  'Consolidation': 'The process in which the lung tissue becomes filled with liquid instead of air, often due to pneumonia.'
};