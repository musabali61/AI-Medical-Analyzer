import React, { useState } from 'react';
import { AnalysisResult as AnalysisResultType, KeyFinding, AbnormalValue } from '../../types';
import { AlertTriangle, CheckCircle, Info, Download, Printer } from 'lucide-react';

interface AnalysisResultProps {
  result: AnalysisResultType;
  reportTitle: string;
}

const AnalysisResult: React.FC<AnalysisResultProps> = ({ result, reportTitle }) => {
  const [activeTab, setActiveTab] = useState('summary');

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'severe':
        return 'text-red-700 bg-red-50 border-red-200';
      case 'moderate':
        return 'text-yellow-700 bg-yellow-50 border-yellow-200';
      case 'normal':
      default:
        return 'text-green-700 bg-green-50 border-green-200';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'severe':
        return <AlertTriangle className="h-5 w-5 text-red-500" />;
      case 'moderate':
        return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      case 'normal':
      default:
        return <CheckCircle className="h-5 w-5 text-green-500" />;
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleDownload = () => {
    // In a real app, this would generate a PDF
    alert('Download functionality would be implemented here');
  };

  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden">
      <div className="p-6 border-b border-gray-200">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-semibold text-gray-800">{reportTitle} Analysis</h2>
          <div className="flex space-x-2">
            <button 
              onClick={handlePrint}
              className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-md transition-colors"
            >
              <Printer className="h-5 w-5" />
            </button>
            <button 
              onClick={handleDownload}
              className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-md transition-colors"
            >
              <Download className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>

      <div className="border-b border-gray-200">
        <nav className="-mb-px flex">
          {['summary', 'findings', 'abnormal', 'recommendations'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`whitespace-nowrap py-4 px-6 border-b-2 font-medium text-sm ${
                activeTab === tab
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </nav>
      </div>

      <div className="p-6">
        {activeTab === 'summary' && (
          <div className="prose max-w-none">
            <div className="p-4 bg-blue-50 rounded-lg mb-6">
              <p className="text-blue-800 text-sm leading-relaxed">{result.summary}</p>
            </div>
          </div>
        )}

        {activeTab === 'findings' && (
          <div className="space-y-4">
            {result.keyFindings.map((finding, index) => (
              <div key={index} className={`p-4 border rounded-lg ${getSeverityColor(finding.severity)}`}>
                <div className="flex items-start">
                  <div className="flex-shrink-0 mr-3 mt-0.5">
                    {getSeverityIcon(finding.severity)}
                  </div>
                  <div>
                    <h4 className="font-medium">{finding.text}</h4>
                    <p className="mt-1 text-sm opacity-90">{finding.explanation}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'abnormal' && (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Value</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Reference Range</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Interpretation</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {result.abnormalValues.map((value, index) => (
                  <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{value.name}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-medium">
                      {value.value} <span className="text-gray-500 font-normal">{value.unit}</span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{value.referenceRange}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{value.interpretation}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {activeTab === 'recommendations' && (
          <div className="space-y-4">
            {result.recommendations.map((recommendation, index) => (
              <div key={index} className="flex items-start p-3 border-l-4 border-blue-400 bg-blue-50 rounded-r-md">
                <Info className="h-5 w-5 text-blue-500 mr-3 flex-shrink-0 mt-0.5" />
                <p className="text-blue-800">{recommendation}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default AnalysisResult;