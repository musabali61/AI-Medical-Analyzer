import React from 'react';
import { Report, ReportType } from '../../types';
import { FileText, Calendar, Clock, ArrowRight } from 'lucide-react';

interface RecentReportsProps {
  reports: Report[];
  onSelectReport: (id: string) => void;
}

const RecentReports: React.FC<RecentReportsProps> = ({ reports, onSelectReport }) => {
  const getReportTypeIcon = (type: ReportType) => {
    return <FileText className="h-5 w-5 text-blue-500" />;
  };

  // Sort reports by date (newest first)
  const sortedReports = [...reports].sort((a, b) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden">
      <div className="p-6 border-b border-gray-200">
        <h2 className="text-xl font-semibold text-gray-800">Recent Reports</h2>
      </div>

      {sortedReports.length === 0 ? (
        <div className="p-6 text-center">
          <p className="text-gray-500">No reports available yet.</p>
          <p className="text-sm text-gray-400 mt-1">Upload a medical report to get started.</p>
        </div>
      ) : (
        <ul className="divide-y divide-gray-200">
          {sortedReports.map((report) => (
            <li 
              key={report.id} 
              className="hover:bg-gray-50 transition-colors duration-150 ease-in-out cursor-pointer"
              onClick={() => onSelectReport(report.id)}
            >
              <div className="p-4 sm:px-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      {getReportTypeIcon(report.type)}
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-900">
                        {report.title}
                      </p>
                      <div className="flex items-center mt-1">
                        <Calendar className="h-4 w-4 text-gray-400 mr-1" />
                        <p className="text-xs text-gray-500">{report.date}</p>
                        <span className="mx-2 text-gray-300">•</span>
                        <p className="text-xs text-gray-500">{report.type}</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center">
                    {report.analyzed ? (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                        Analyzed
                      </span>
                    ) : (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                        Pending
                      </span>
                    )}
                    <ArrowRight className="ml-4 h-4 w-4 text-gray-400" />
                  </div>
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}

      {sortedReports.length > 0 && (
        <div className="p-4 border-t border-gray-200">
          <button className="text-sm text-blue-600 hover:text-blue-800 font-medium flex items-center">
            View all reports
            <ArrowRight className="ml-1 h-4 w-4" />
          </button>
        </div>
      )}
    </div>
  );
};

export default RecentReports;