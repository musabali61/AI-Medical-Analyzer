import React, { useState } from 'react';
import Navbar from '../components/layout/Navbar';
import UploadArea from '../components/upload/UploadArea';
import RecentReports from '../components/dashboard/RecentReports';
import AnalysisResult from '../components/analysis/AnalysisResult';
import { sampleReports, sampleAnalysisResults } from '../services/mockData';
import { Report, ReportType } from '../types';

const Dashboard: React.FC = () => {
  const [reports, setReports] = useState(sampleReports);
  const [selectedReportId, setSelectedReportId] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const selectedReport = selectedReportId 
    ? reports.find(report => report.id === selectedReportId) 
    : null;
  
  const analysisResult = selectedReportId && selectedReportId in sampleAnalysisResults
    ? sampleAnalysisResults[selectedReportId]
    : null;

  const handleFileSelected = (file: File, type: ReportType) => {
    setIsAnalyzing(true);
    
    // Simulate analysis delay
    setTimeout(() => {
      const newReport: Report = {
        id: `${reports.length + 1}`,
        title: file.name.replace(/\.[^/.]+$/, ""), // Remove file extension
        date: new Date().toISOString().split('T')[0],
        content: 'Uploaded report content would be extracted here...',
        type: type,
        analyzed: true
      };
      
      setReports([newReport, ...reports]);
      setSelectedReportId(newReport.id);
      setIsAnalyzing(false);
    }, 2000);
  };

  const handleSelectReport = (id: string) => {
    setSelectedReportId(id);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Medical Report Analysis</h1>
          <p className="mt-1 text-sm text-gray-500">
            Upload your medical reports to get AI-powered insights and explanations.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-1">
            <div className="space-y-6">
              <UploadArea onFileSelected={handleFileSelected} />
              
              <div className="hidden md:block">
                <RecentReports 
                  reports={reports} 
                  onSelectReport={handleSelectReport} 
                />
              </div>
            </div>
          </div>
          
          <div className="md:col-span-2">
            {isAnalyzing ? (
              <div className="bg-white rounded-xl shadow-sm p-8 flex flex-col items-center justify-center h-96">
                <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500 mb-4"></div>
                <h3 className="text-lg font-medium text-gray-900">Analyzing your report...</h3>
                <p className="text-gray-500 mt-2 text-center max-w-md">
                  Our AI is extracting and interpreting the medical information.
                  This usually takes less than a minute.
                </p>
              </div>
            ) : selectedReport && analysisResult ? (
              <AnalysisResult 
                result={analysisResult} 
                reportTitle={selectedReport.title} 
              />
            ) : selectedReport ? (
              <div className="bg-white rounded-xl shadow-sm p-8 flex flex-col items-center justify-center h-96">
                <h3 className="text-lg font-medium text-gray-900">Report not yet analyzed</h3>
                <p className="text-gray-500 mt-2 text-center">
                  This report is still pending analysis. Please check back later.
                </p>
              </div>
            ) : (
              <div className="bg-white rounded-xl shadow-sm p-8 flex flex-col items-center justify-center h-96">
                <div className="rounded-full bg-blue-100 p-3 mb-4">
                  <svg className="h-8 w-8 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                </div>
                <h3 className="text-lg font-medium text-gray-900">No report selected</h3>
                <p className="text-gray-500 mt-2 text-center max-w-md">
                  Upload a new report or select one from your recent reports to view its analysis.
                </p>
              </div>
            )}
            
            <div className="md:hidden mt-6">
              <RecentReports 
                reports={reports} 
                onSelectReport={handleSelectReport} 
              />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;