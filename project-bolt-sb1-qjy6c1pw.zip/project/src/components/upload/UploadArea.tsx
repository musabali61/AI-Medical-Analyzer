import React, { useState } from 'react';
import { Upload, File, AlertCircle, CheckCircle } from 'lucide-react';
import { ReportType } from '../../types';

interface UploadAreaProps {
  onFileSelected: (file: File, type: ReportType) => void;
}

const UploadArea: React.FC<UploadAreaProps> = ({ onFileSelected }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [reportType, setReportType] = useState<ReportType>(ReportType.LAB);
  const [error, setError] = useState<string | null>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const processFile = (file: File) => {
    if (!file) return;
    
    // Check if file is PDF or text file
    if (file.type !== 'application/pdf' && !file.type.startsWith('text/')) {
      setError('Please upload a PDF or text file');
      setFile(null);
      return;
    }
    
    if (file.size > 10 * 1024 * 1024) { // 10MB limit
      setError('File size exceeds 10MB limit');
      setFile(null);
      return;
    }
    
    setFile(file);
    setError(null);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processFile(e.target.files[0]);
    }
  };

  const handleSubmit = () => {
    if (file) {
      onFileSelected(file, reportType);
    }
  };

  return (
    <div className="w-full p-6 bg-white rounded-xl shadow-sm">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">Upload Medical Report</h2>
      
      <div 
        className={`border-2 border-dashed rounded-lg p-8 text-center ${
          isDragging ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-blue-400'
        } transition-colors duration-200 ease-in-out`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <div className="flex flex-col items-center justify-center space-y-4">
          <div className="p-3 bg-blue-100 rounded-full">
            <Upload className="h-8 w-8 text-blue-600" />
          </div>
          
          <div className="space-y-1">
            <p className="text-base font-medium text-gray-700">
              Drag and drop your file here, or
            </p>
            <label className="cursor-pointer text-blue-600 hover:text-blue-700 font-medium">
              browse files
              <input 
                type="file" 
                className="hidden" 
                onChange={handleFileChange}
                accept=".pdf,.txt,.doc,.docx"
              />
            </label>
          </div>
          
          <p className="text-xs text-gray-500">
            Supported formats: PDF, TXT, DOC, DOCX (Max size: 10MB)
          </p>
        </div>
      </div>
      
      {error && (
        <div className="mt-4 flex items-center p-3 bg-red-50 text-red-700 rounded-md">
          <AlertCircle className="h-5 w-5 mr-2 flex-shrink-0" />
          <p className="text-sm">{error}</p>
        </div>
      )}
      
      {file && !error && (
        <div className="mt-4 flex items-center p-3 bg-green-50 text-green-700 rounded-md">
          <CheckCircle className="h-5 w-5 mr-2 flex-shrink-0" />
          <div className="flex-1 flex items-center justify-between">
            <div className="flex items-center">
              <File className="h-5 w-5 mr-2" />
              <p className="text-sm font-medium truncate max-w-xs">{file.name}</p>
            </div>
            <span className="text-xs text-gray-500">{(file.size / 1024).toFixed(0)} KB</span>
          </div>
        </div>
      )}
      
      <div className="mt-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Report Type
        </label>
        <select
          value={reportType}
          onChange={(e) => setReportType(e.target.value as ReportType)}
          className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
        >
          {Object.values(ReportType).map((type) => (
            <option key={type} value={type}>{type}</option>
          ))}
        </select>
      </div>
      
      <div className="mt-6">
        <button
          onClick={handleSubmit}
          disabled={!file || !!error}
          className={`w-full flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-base font-medium text-white ${
            !file || !!error
              ? 'bg-gray-300 cursor-not-allowed'
              : 'bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500'
          }`}
        >
          Analyze Report
        </button>
      </div>
    </div>
  );
};

export default UploadArea;