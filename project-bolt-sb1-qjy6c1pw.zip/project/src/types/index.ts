export interface Report {
  id: string;
  title: string;
  date: string;
  content: string;
  type: ReportType;
  analyzed: boolean;
}

export enum ReportType {
  LAB = "Lab Result",
  RADIOLOGY = "Radiology",
  PATHOLOGY = "Pathology",
  DISCHARGE = "Discharge Summary",
  OTHER = "Other"
}

export interface AnalysisResult {
  summary: string;
  keyFindings: KeyFinding[];
  abnormalValues: AbnormalValue[];
  recommendations: string[];
}

export interface KeyFinding {
  text: string;
  explanation: string;
  severity: "normal" | "moderate" | "severe";
}

export interface AbnormalValue {
  name: string;
  value: string;
  unit: string;
  referenceRange: string;
  interpretation: string;
}