import React, { useState } from 'react';
import { HelpCircle, X } from 'lucide-react';

interface TermExplainerProps {
  term: string;
  definition: string;
}

const TermExplainer: React.FC<TermExplainerProps> = ({ term, definition }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <span className="relative inline-block">
      <span 
        className="underline decoration-dotted cursor-help text-blue-600"
        onClick={() => setIsOpen(true)}
      >
        {term}
      </span>
      <HelpCircle className="inline-block ml-0.5 h-3.5 w-3.5 text-blue-500 cursor-help" />
      
      {isOpen && (
        <>
          <div 
            className="fixed inset-0 bg-black bg-opacity-25 z-40"
            onClick={() => setIsOpen(false)}
          ></div>
          
          <div className="absolute z-50 w-72 p-4 bg-white rounded-lg shadow-lg border border-gray-200 text-left">
            <div className="flex justify-between items-start">
              <h4 className="font-medium text-gray-900">{term}</h4>
              <button 
                onClick={() => setIsOpen(false)}
                className="text-gray-400 hover:text-gray-500"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <p className="mt-2 text-sm text-gray-600">{definition}</p>
          </div>
        </>
      )}
    </span>
  );
};

export default TermExplainer;